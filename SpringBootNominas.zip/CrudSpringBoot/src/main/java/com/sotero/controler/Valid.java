package com.sotero.controler;

public @interface Valid {

}
